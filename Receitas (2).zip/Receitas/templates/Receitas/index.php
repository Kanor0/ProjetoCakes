<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Receita[]|\Cake\Collection\CollectionInterface $receitas
 */
?>
<div class="receitas index content">
    <?= $this->Html->link(__('New Receita'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Receitas') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('title') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th><?= $this->Paginator->sort('user_id') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($receitas as $receita): ?>
                <tr>
                    <td><?= $this->Number->format($receita->id) ?></td>
                    <td><?= h($receita->title) ?></td>
                    <td><?= h($receita->created) ?></td>
                    <td><?= h($receita->modified) ?></td>
                    <td><?= $receita->has('user') ? $this->Html->link($receita->user->id, ['controller' => 'Users', 'action' => 'view', $receita->user->id]) : '' ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $receita->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $receita->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $receita->id], ['confirm' => __('Are you sure you want to delete # {0}?', $receita->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
         <p align="left">
            <?="Pagina Atual->",$this->Paginator->current('Users');?>
        </p>
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
