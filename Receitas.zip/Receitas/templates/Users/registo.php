<br>
<div class="index large-4 medium-4 large-offset-4 medium-offset-4 collumns">
    <div class="panel content">

        <h2 class="text-center title">Register</h2>
        <?= $this->Form->create(); ?>

            <?= $this->Form->control('nome'); ?>
            <?= $this->Form->control('email'); ?>
            <?= $this->Form->control('password'); ?>
            <?= $this->Form->submit('Registo'); ?>
            
        <?= $this->Form->end(); ?>
    </div>
</div>